#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

int main() {
	string input;
	while(cin)
	{
		// Here you would be reading the file line by line
		getline(cin, input);
		cout<<"The input is: "<<input;
		/*
		Here evaluate the current line and printout the result
		Using the class you implemented
		*/
	}
	return 0;
}

